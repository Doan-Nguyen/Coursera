# Linear Algebra

## Matrices and Vectors
+ Matrix: rectangular array of numbers
    - Dimension of matrix: number of rows x number of columns 
    - Matrix Elements:
        - $A_{ij}$: element in the $i^th$ row, $j^th$ column.
+ Vector: an nx1 matrix (n-dimensional vector)

## Addition and Scalar Multiplication
