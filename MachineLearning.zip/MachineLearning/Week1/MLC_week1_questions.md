# 1. Why linear regression used the square error cost function ? 


# 2. How to find the local minimum ? 
+ The conditions gets a local minimum:
    - The derivative term = 0 => parameters not updates.
    
# 3. Why need simultaneous updates ?

## 3.1 If using non-simultaneous can find local minimum ?

# 4. If gradient descent at a local minimum, the algorithm find continuously the global optimal ?
- If find a local minimum, the gradient don't update parameter which be derivate.
Nếu tìm ra điểm tối ưu local, thuật toán k cập nhật cho tham số đang xét.
