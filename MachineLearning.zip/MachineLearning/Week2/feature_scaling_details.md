# All about Feature Scaling 

+ In machine learning, to bring all features in the same standing, we need to do scaling.

## Reference:
[1] https://towardsdatascience.com/all-about-feature-scaling-bcc0ad75cb35