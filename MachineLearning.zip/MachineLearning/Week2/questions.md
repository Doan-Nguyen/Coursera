# 1. Why similar range of values -> converge more quickly ? 1

# 2. What is normalization ? how many type of normalization ? 
+ Normalization & standardization dataset
+ Zero mean
+ standard deviation

# 3. How many ways to converge more quickly ? 

# 4. How to do when gradient descent not decrease ? Why ? 

# 5. How to know when change learning rate ? 
+ What sign to know learning rate too low or too high ? 

# 6. Features and polynomial regression 
- When using polynomial regression ? 
- How to choice hypothesis function to quadratic, cubic or square root function ? 

# 7. The following equation 
+ An analytical approach to Linear Regression with a Least Square Cost Function.

+ **Pros and cons of Normal Equation ?**

+ Maths behind the equation:
    - Hypothesis function:
        
        $h(\theta) = \theta_{0} x_{0} + \theta_{1} x_{1} + ... + \theta_{n} x_{n} = \theta^{T} X$

        - n: number of features

    - The motive of Linear Regression is to minimize the *cost function*:

        $J(\theta) = \frac{1}{2m} \sum_{i=0}^{m}(h(\theta_i)(x^{(i)}) - y^{(i)})^{2}$

        - $x^{i}$

# 8. Pseudo-inverse & inverse ? 

# 9. Redundant features & regularization ? 