1. Why sigmoid better than ReLU ? 

2. Linear regression's cost function: least square error. Logistic regression using cost function: sigmoid function. Why ? 
- least square error -> non-convex ? => gradient descent may not find the global optimum.

3. Why not using linear regression for binary classification ? 
- Want: y

4. 
e^0 ~ 1
- $0 \leq \hat{y}^{(i)} \leq 1$ ? 

5. The cost function that measure how well your parameters w & b are doing on your entire training set.
- Gradient descent to train & to learn w, b on training set.

6. the poin initialize best ? 

7. How to check a computation is convex ? 